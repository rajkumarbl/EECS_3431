/** @file rt_material.cpp
 *
 *  @brief Implementation of material storage class
 *
 **/

#include <rt_material.h>

rt_Material::rt_Material( rt_parse *parser, char *n, Vec3f dc, Vec3f sc, 
                          float shine, Vec3f tc, Vec3f rc, float ri)
{}
