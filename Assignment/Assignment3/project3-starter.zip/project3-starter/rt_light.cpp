/** @file rt_light.c
 *
 *  @brief Implementation of the rt_light object
 *
 **/
 
#include <rt_light.h>

rt_Light::rt_Light(rt_parse *parser, Vec3f p, Vec3f c, float a1, float a2, 
                   float a3)
{}
