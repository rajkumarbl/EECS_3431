/** @file rt_triangle.cpp
 *
 *  @brief Implementation of a raytracer triangle
 *
 *  You should add your code here
 **/
 
#include <rt_triangle.h>

rt_Triangle::rt_Triangle(rt_parse *parser, Vec3f p0, Vec3f p1, Vec3f p2,
                      Vec3f n0, Vec3f n1, Vec3f n2,
                      int m0, int m1, int m2,
                      float ts0, float tt0,
                      float ts1, float tt1,
                      float ts2, float tt2)
    : rt_Object(parser)
{}
