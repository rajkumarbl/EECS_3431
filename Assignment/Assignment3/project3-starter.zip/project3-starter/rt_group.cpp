/*** @file rt_group.cpp
 *
 *   @brief Implementation of group class
 *
 *   You should add your code here.
 **/
 
#include <rt_group.h>

rt_Group::rt_Group(rt_parse *parser)
{
  /* add your own code here */
}

void rt_Group::add(rt_Object *o)
{
  /* add your own code here */
}

