/** @file rt_sphere.cpp
 *
 *  @brief Implementation of a raytracer sphere
 *
 **/

#include <rt_sphere.h>
rt_Sphere::rt_Sphere(rt_parse *parser, Vec3f c, float r, int mi)
  : rt_Object(parser)  
{
}
