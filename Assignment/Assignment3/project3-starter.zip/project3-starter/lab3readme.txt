AUTHOR/ANDREW ID:

MANDATORY FEATURES
------------------

<Under "Status" please indicate whether it has been implemented and is
functioning correctly.  If not, please explain the current status.>

Feature:                                 Status:
-------------------------------------    ------------------------
1) Ray Tracing a Sphere

2) Ray Tracing a Triangle

3) Ray Tracing an OBJ File

4) Texture Mapping OBJ Files

5) Phong Shading

6) Shadows

7) Recursive Reflection

8) Representative Scene

OPTIONAL FEATURES:
------------------

<Please indicate whether or not you implemented any optional features,
and include a description of their current status.>

Feature:                                 Status:
--------------------------------         ------------------------
1) Recursive Refraction

2) Soft Shadows

3) Depth Field

4) Motion Blur

5) Spatial Partitioning

6) Normal Mapping, Specular Mapping

OTHER KNOWN BUGS/ISSUES:
------------------------

<list any known problems, if any>
