/***
 *  @file rt_object.cpp
 *
 *  @brief Implementation of Object code
 *
 ***/

#include <rt_object.h>


rt_Object::rt_Object(rt_parse *parser)
{
}

