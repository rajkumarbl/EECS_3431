#include <stdlib.h>
#include <gfx/gl.h>
#include <GL/glext.h>
#include <GL/glut.h>

#include "rt_parse.h"

int g_windowSize[2] = {320, 240};
rt_parse* g_parser=NULL;

void keyboardKeyPressed(unsigned char key, int x, int y)
{
  switch (key) {
  case 'q':
  case 'Q':
    exit(0);
  }
}

void idle()
{
  glutPostRedisplay();
}

void display()
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // draw something

  glutSwapBuffers();
}

int main(int argc, char* argv[])
{
  const char* filename = "test.ray";
  // process the command line

  // parse the file
  //g_parser = new rt_parse(filename);

  glutInit(&argc, argv);

  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize(g_windowSize[0], g_windowSize[1]);

  glutCreateWindow("My Awesome 15-462 Project 3");

  glutKeyboardFunc(keyboardKeyPressed);
  glutIdleFunc(idle);
  glutDisplayFunc(display);
  glutMainLoop();

  delete g_parser;
  return 0;
}
